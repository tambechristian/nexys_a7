
// Copyright (C) 2016 Christian Tambe
// Copyright (C) 2016 William Fonkou Tambe

#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/init.h>

#include <linux/kernel.h>
#include <linux/interrupt.h>
#include <linux/workqueue.h>
#include <linux/fs.h>
#include <linux/errno.h>
#include <linux/types.h>
#include <linux/vmalloc.h>
#include <linux/genhd.h>
#include <linux/blkdev.h>
#include <linux/hdreg.h>
#include <linux/version.h>

#include <asm/io.h> // ioremap() iounmap()

#include <linux/of_device.h>
#include <linux/of_address.h>
#include <linux/of_irq.h>
#include <linux/platform_device.h>

// Set to non-null to get debug printk() infos.
// -1 should print all debug infos, while other
// non-null values should selectively print debug infos.
static int debug = 0;
module_param(debug, int, 0644);

// Set to non-null to disable
// the use of interrupt when
// reading/writing the sdcard.
static int irqoff = 0;
module_param(irqoff, int, 0644);

// Set to non-null to disable
// the use of workqueue when
// reading/writing the sdcard.
static int workqueueoff = 0;
module_param(workqueueoff, int, 0644);

#include "cntrlr.axi4sdcard.c"

// Name to use with this driver.
static u8* axi4sdcarddrvname = "axi4sdcard";

// Name to use with the block device file.
static u8* axi4sdcardblkdevname = "sdcard";

// 5 account for the block device file
// for the whole SDCard device and
// the block device files for partitions.
// Only the MBR format is supported, which
// has a maximum partition count of 4.
#define MAXNBROFBLKDEVFILES (1+4)

// Structure used to hold information
// of an SDCard controller and
// its block device files to create.
struct axi4sdcard {
	struct work_struct work; // Work which get scheduled to process block queue data.
							// This field must be first in this structure,
							// as its address is used to retrieve the other fields.
	struct request_queue* workarg; // Argument for the handler of the work.
	struct workqueue_struct* workqueue; // Workqueue used for scheduling work to process block queue data.
	sdcardcntrlr cntrlr;
	uint majornum;
	uint blkoffset[MAXNBROFBLKDEVFILES];
	uint blkcnt[MAXNBROFBLKDEVFILES];
	struct gendisk* gd[MAXNBROFBLKDEVFILES];
	struct request_queue* blkqueue;
	spinlock_t blkqueuelock;
	u8* drvname;
};

static struct of_device_id axi4sdcard_of_match[] = {
	{.compatible = "xlnx,axi4sdcard-1.00.a",},
	{}
};
MODULE_DEVICE_TABLE(of, axi4sdcard_of_match);

static int axi4sdcard_drv_probe (struct platform_device* pdev) {
	
	if (debug == 1 || debug == -1) {
		printk(KERN_INFO "axi4sdcard: %s() entry\n", __FUNCTION__);
	}
	
	struct axi4sdcard* sdcard = kzalloc(sizeof(struct axi4sdcard), GFP_KERNEL);
	if (!sdcard) return -ENOMEM;
	
	// Keep track of the number of time
	// this function was called.
	static uint probecnt = 0;
	
	// (sizeof(uint)*8)+1 account for the space used for appending
	// the controller index and the null-terminating byte.
	uint drvnamesz = strlen(axi4sdcarddrvname)+(sizeof(uint)*8)+1;
	
	if (!(sdcard->drvname = kmalloc(drvnamesz, GFP_KERNEL))) {
		kfree(sdcard);
		return -ENOMEM;
	}
	snprintf(sdcard->drvname, drvnamesz, "%s%u", axi4sdcarddrvname, probecnt);
	
	platform_set_drvdata(pdev, sdcard);
	
	spin_lock_init(&sdcard->cntrlr.lock);
	
	init_waitqueue_head(&sdcard->cntrlr.waitqueue);
	
	if (!workqueueoff) {
		if (!(sdcard->workqueue = create_workqueue(sdcard->drvname)))
			return -ENOMEM;
	}
	
	if (!of_match_device(axi4sdcard_of_match, &pdev->dev))
		return -EINVAL;
	
	struct resource res;
	
	if (of_address_to_resource(pdev->dev.of_node, 0, &res)) return -ENOMEM;
	
	if (!(sdcard->cntrlr.addr = ioremap(res.start, resource_size(&res)))) return -ENOMEM;
	
	if (debug == 1 || debug == -1) {
		printk(KERN_INFO "axi4sdcard: ioremap(0x%x, 0x%x) == 0x%x\n",
			(uint)res.start, (uint)resource_size(&res), (uint)sdcard->cntrlr.addr);
	}
	
	if (!irqoff) {
		
		irqreturn_t irqhandler (int irq, void* devid) {
			
			if (irqoff) return IRQ_HANDLED;
			
			struct axi4sdcard* sdcard = (struct axi4sdcard*)devid;
			
			if (debug == 1 || debug == -1) {
				printk(KERN_INFO "axi4sdcard: %s(irq == %u) entry\n", __FUNCTION__, sdcard->cntrlr.irq);
			}
			
			wake_up_interruptible_sync(&sdcard->cntrlr.waitqueue);
			
			if (debug == 1 || debug == -1) {
				printk(KERN_INFO "axi4sdcard: %s() exit\n", __FUNCTION__);
			}
			
			return IRQ_HANDLED;
		}
		
		if ((sdcard->cntrlr.irq = irq_of_parse_and_map(pdev->dev.of_node, 0))) {
			
			int rc = request_irq(sdcard->cntrlr.irq, irqhandler, IRQF_SHARED, sdcard->drvname, (void*)sdcard);
			if (rc) {
				printk(KERN_ERR "axi4sdcard: error: request_irq(%u) == %d\n", sdcard->cntrlr.irq, rc);
				return rc;
			}
			
			if (debug == 1 || debug == -1) {
				printk(KERN_INFO "axi4sdcard: request_irq(%u)\n", sdcard->cntrlr.irq);
			}
		}
	}
	
	while (!sdcardcntrlrinit(&sdcard->cntrlr));
	
	if (debug == 1 || debug == -1) {
		uint size;
		if ((size = sdcard->cntrlr.blockcount/((1024*1024*1024)/512)))
			printk(KERN_INFO "axi4sdcard: SDCard initialized; SDCard size: %u GBytes\n", size);
		else if ((size = sdcard->cntrlr.blockcount/((1024*1024)/512)))
			printk(KERN_INFO "axi4sdcard: SDCard initialized; SDCard size: %u MBytes\n", size);
		else if ((size = sdcard->cntrlr.blockcount/(1024/512)))
			printk(KERN_INFO "axi4sdcard: SDCard initialized; SDCard size: %u KBytes\n", size);
		else printk(KERN_INFO "axi4sdcard: SDCard initialized; SDCard size: %u Bytes\n", sdcard->cntrlr.blockcount*512);
	}
	
	sdcard->blkcnt[0] = sdcard->cntrlr.blockcount;
	sdcard->blkoffset[0] = 0;
	
	// Structure describing the
	// Master Boot Record (MBR).
	struct __attribute__((__packed__)) {

		u8 bootcode[446];

		struct {

			u8 bootflag;
			u8 chsbegin[3];
			u8 type;
			u8 chsend[3];
			u32 lbabegin;
			u32 blockcount;

		} partition[4];

		u16 bootsignature;

	} mbr;
	
	// Load the Master Boot Record (MBR).
	while (!sdcardcntrlrread(&sdcard->cntrlr, (void*)&mbr, 0, 1)) {
		// If I get here, sdcardcntrlrread() was not able
		// to read all the blocks; I re-initialize
		// the SDCard controller and continue reading.
		
		if (debug == 1 || debug == -1) {
			printk(KERN_INFO "axi4sdcard: SDCard read-failure; blockoffset: %u\n", 0);
		}

		while (!sdcardcntrlrinit(&sdcard->cntrlr));
		
		if (debug == 1 || debug == -1) {
			uint size;
			if ((size = sdcard->cntrlr.blockcount/((1024*1024*1024)/512)))
				printk(KERN_INFO "axi4sdcard: SDCard re-initialized; SDCard size: %u GBytes\n", size);
			else if ((size = sdcard->cntrlr.blockcount/((1024*1024)/512)))
				printk(KERN_INFO "axi4sdcard: SDCard re-initialized; SDCard size: %u MBytes\n", size);
			else if ((size = sdcard->cntrlr.blockcount/(1024/512)))
				printk(KERN_INFO "axi4sdcard: SDCard re-initialized; SDCard size: %u KBytes\n", size);
			else printk(KERN_INFO "axi4sdcard: SDCard re-initialized; SDCard size: %u Bytes\n", sdcard->cntrlr.blockcount*512);
		}
	}
	
	if (debug == 1 || debug == -1) {
		printk(KERN_INFO "axi4sdcard: MBR loaded\n");
	}
	
	sdcard->blkcnt[1] = mbr.partition[0].blockcount;
	sdcard->blkoffset[1] = mbr.partition[0].lbabegin;
	sdcard->blkcnt[2] = mbr.partition[1].blockcount;
	sdcard->blkoffset[2] = mbr.partition[1].lbabegin;
	sdcard->blkcnt[3] = mbr.partition[2].blockcount;
	sdcard->blkoffset[3] = mbr.partition[2].lbabegin;
	sdcard->blkcnt[4] = mbr.partition[3].blockcount;
	sdcard->blkoffset[4] = mbr.partition[3].lbabegin;
	
	if (debug == 1 || debug == -1) {
		printk(KERN_INFO "axi4sdcard: partition0, blkoffset: %u, blockcount: %u\n",
			sdcard->blkoffset[1], sdcard->blkcnt[1]);
		printk(KERN_INFO "axi4sdcard: partition1, blkoffset: %u, blockcount: %u\n",
			sdcard->blkoffset[2], sdcard->blkcnt[2]);
		printk(KERN_INFO "axi4sdcard: partition2, blkoffset: %u, blockcount: %u\n",
			sdcard->blkoffset[3], sdcard->blkcnt[3]);
		printk(KERN_INFO "axi4sdcard: partition3, blkoffset: %u, blockcount: %u\n",
			sdcard->blkoffset[4], sdcard->blkcnt[4]);
	}
	
	void blkqueuework (struct work_struct* work) {
		
		if (debug == 1 || debug == -1) {
			printk(KERN_INFO "axi4sdcard: %s() entry\n", __FUNCTION__);
		}
		
		// Handle an I/O request; actual data transfer.
		void datatransfer (struct gendisk* gd, sector_t sectoffset, uint sectcnt, u8* buffer, uint iswrite) {
			
			if (debug == 1 || debug == -1) {
				printk(KERN_INFO "axi4sdcard: %s() entry\n", __FUNCTION__);
			}
			
			struct axi4sdcard* sdcard = (struct axi4sdcard*)gd->private_data;
			
			uint i = gd->first_minor;
			uint devblkcnt = sdcard->blkcnt[i];
			uint devblkoffset = sdcard->blkoffset[i];
			
			if ((sectoffset + sectcnt) > devblkcnt) {
				printk(KERN_ERR "axi4sdcard: beyond-end access: sectoffset == %u, sectcnt == %u, i == %u, devblkoffset == %u, devblkcnt == %u\n",
					(uint)sectoffset, sectcnt, i, devblkoffset, devblkcnt);
				return;
			}
			
			sectoffset += devblkoffset;
			
			if (iswrite) {
				
				uint nsectwritten = 0;
				
				while (sectcnt - (nsectwritten += sdcardcntrlrwrite(&sdcard->cntrlr,
					buffer + (nsectwritten*512),
						sectoffset + nsectwritten,
							sectcnt - nsectwritten))) {
					
					// If I get here, sdcardcntrlrwrite() was not able
					// to written all the blocks; I re-initialize
					// the SDCard controller and continue writtening.
					
					if (debug == 1 || debug == -1) {
						printk(KERN_INFO "axi4sdcard: write-failure; blockoffset: %u\n", (uint)sectoffset + nsectwritten);
					}
					
					while (!sdcardcntrlrinit(&sdcard->cntrlr));
					
					if (debug == 1 || debug == -1) {
						uint size;
						if ((size = sdcard->cntrlr.blockcount/((1024*1024*1024)/512)))
							printk(KERN_INFO "axi4sdcard: SDCard re-initialized; SDCard size: %u GBytes\n", size);
						else if ((size = sdcard->cntrlr.blockcount/((1024*1024)/512)))
							printk(KERN_INFO "axi4sdcard: SDCard re-initialized; SDCard size: %u MBytes\n", size);
						else if ((size = sdcard->cntrlr.blockcount/(1024/512)))
							printk(KERN_INFO "axi4sdcard: SDCard re-initialized; SDCard size: %u KBytes\n", size);
						else printk(KERN_INFO "axi4sdcard: SDCard re-initialized; SDCard size: %u Bytes\n", sdcard->cntrlr.blockcount*512);
					}
				}
				
			} else { // else read.
				
				uint nsectreaded = 0;
				
				while (sectcnt - (nsectreaded += sdcardcntrlrread(&sdcard->cntrlr,
					buffer + (nsectreaded*512),
						sectoffset + nsectreaded,
							sectcnt - nsectreaded))) {
					
					// If I get here, sdcardcntrlrread() was not able
					// to read all the blocks; I re-initialize
					// the SDCard controller and continue reading.
					
					if (debug == 1 || debug == -1) {
						printk(KERN_INFO "axi4sdcard: read-failure; blockoffset: %u\n", (uint)sectoffset + nsectreaded);
					}
					
					while (!sdcardcntrlrinit(&sdcard->cntrlr));
					
					if (debug == 1 || debug == -1) {
						uint size;
						if ((size = sdcard->cntrlr.blockcount/((1024*1024*1024)/512)))
							printk(KERN_INFO "axi4sdcard: SDCard re-initialized; SDCard size: %u GBytes\n", size);
						else if ((size = sdcard->cntrlr.blockcount/((1024*1024)/512)))
							printk(KERN_INFO "axi4sdcard: SDCard re-initialized; SDCard size: %u MBytes\n", size);
						else if ((size = sdcard->cntrlr.blockcount/(1024/512)))
							printk(KERN_INFO "axi4sdcard: SDCard re-initialized; SDCard size: %u KBytes\n", size);
						else printk(KERN_INFO "axi4sdcard: SDCard re-initialized; SDCard size: %u Bytes\n", sdcard->cntrlr.blockcount*512);
					}
				}
			}
			
			if (debug == 1 || debug == -1) {
				printk(KERN_INFO "axi4sdcard: %s() exit\n", __FUNCTION__);
			}
		}
		
		struct request_queue* q = ((struct axi4sdcard*)work)->workarg;
		
		struct request* req;
		
		while ((req = blk_fetch_request(q)) != NULL) {
			keepprocessingreq:
			
			if (req->cmd_type != REQ_TYPE_FS) {
				printk(KERN_NOTICE "axi4sdcard: skip non-cmd request\n");
				__blk_end_request_all(req, -EIO);
				continue;
			}
			
			datatransfer(
				req->rq_disk,
				blk_rq_pos(req),
				blk_rq_cur_sectors(req),
				bio_data(req->bio),
				rq_data_dir(req));
			
			// When __blk_end_request_cur() return true,
			// it mean that there are still data to process
			// from the request.
			if (__blk_end_request_cur(req, 0)) goto keepprocessingreq;
		}
		
		if (debug == 1 || debug == -1) {
			printk(KERN_INFO "axi4sdcard: %s() exit\n", __FUNCTION__);
		}
	}
	
	if (sdcard->workqueue) {
		INIT_WORK(&sdcard->work, blkqueuework);
	}
	
	// I/O requests handler.
	void iorequesthandler (struct request_queue* q) {
		
		if (debug == 1 || debug == -1) {
			printk(KERN_INFO "axi4sdcard: %s() entry\n", __FUNCTION__);
		}
		
		struct request* req;
		
		if ((req = blk_peek_request(q)) != NULL) {
			
			struct axi4sdcard* sdcard = (struct axi4sdcard*)req->rq_disk->private_data;
			
			// Using the request block queue lock,
			// Linux prevent another request_queue
			// from coming through until processing of
			// the current request_queue has been completed.
			// So we are safe from sdcard->workarg getting
			// overwritten by another request_queue.
			sdcard->workarg = q;
			
			if (!sdcard->workqueue || workqueueoff)
				blkqueuework(&sdcard->work);
			else queue_work(sdcard->workqueue, &sdcard->work);
		}
		
		if (debug == 1 || debug == -1) {
			printk(KERN_INFO "axi4sdcard: %s() exit\n", __FUNCTION__);
		}
	}
	
	// Create and initialize the request block queue.
	spin_lock_init(&sdcard->blkqueuelock);
	if (!(sdcard->blkqueue = blk_init_queue(iorequesthandler, &sdcard->blkqueuelock)))
		goto cleanup0;
	
	if (debug == 1 || debug == -1) {
		printk(KERN_INFO "axi4sdcard: blk_init_queue()\n");
	}
	
	blk_queue_logical_block_size(sdcard->blkqueue, 512);
	
	if (debug == 1 || debug == -1) {
		printk(KERN_INFO "axi4sdcard: blk_queue_logical_block_size()\n");
	}
	
	sdcard->majornum = register_blkdev(0, axi4sdcardblkdevname);
	if ((signed)sdcard->majornum < 0) {
		printk(KERN_ERR "axi4sdcard: unable to get major number\n");
		goto cleanup1;
	}
	
	if (debug == 1 || debug == -1) {
		printk(KERN_INFO "axi4sdcard: register_blkdev()\n");
	}
	
	// The HDIO_GETGEO ioctl is handled in blkdev_ioctl(),
	// which call this function. getgeo need to be implemented
	// so that old tools such as fdisk work properly.
	int getgeo (struct block_device* block_device, struct hd_geometry* geo) {
		
		if (debug == 1 || debug == -1) {
			printk(KERN_INFO "axi4sdcard: %s() entry\n", __FUNCTION__);
		}
		
		struct gendisk* gd = block_device->bd_disk;
		
		uint i = gd->first_minor;
		
		struct axi4sdcard* sdcard = (struct axi4sdcard *)gd->private_data;
		
		geo->start = sdcard->blkoffset[i];
		
		uint size = sdcard->blkcnt[i];
		
		// There is no real geometry,
		// so something is made up.
		geo->cylinders = (size & ~0x3f) >> 6;
		geo->heads = 4;
		geo->sectors = 16;
		
		if (debug == 1 || debug == -1) {
			printk(KERN_INFO "axi4sdcard: %s() exit\n", __FUNCTION__);
		}
		
		return 0;
	}
	
	/* // TODO: To uncomment once partition reload has been implemented ...
	uint checkevents (struct gendisk* gd, uint clearing) {
		
		if (debug == 1 || debug == -1) {
			printk(KERN_INFO "axi4sdcard: %s(clearing == 0x%x) entry\n", __FUNCTION__, clearing);
		}
		
		if (gd->first_minor == 0 && (clearing&DISK_EVENT_MEDIA_CHANGE)) { // TODO: To implement ...
			if (debug == 1 || debug == -1) {
				printk(KERN_INFO "axi4sdcard: DISK_EVENT_MEDIA_CHANGE\n");
			}
		}
		
		if (debug == 1 || debug == -1) {
			printk(KERN_INFO "axi4sdcard: %s() exit\n", __FUNCTION__);
		}
		
		return clearing;
	}*/
	
	static struct block_device_operations axi4sdcardblkdevops;
	memzero_explicit((void*)&axi4sdcardblkdevops, sizeof(struct block_device_operations));
	axi4sdcardblkdevops.owner = THIS_MODULE;
	axi4sdcardblkdevops.getgeo = getgeo;
	//axi4sdcardblkdevops.check_events = checkevents; // TODO: To uncomment once partition reload has been implemented ...
	
	if (!(sdcard->gd[0] = alloc_disk(1))) goto cleanup2;
	
	sdcard->gd[0]->major = sdcard->majornum;
	sdcard->gd[0]->first_minor = 0;
	sdcard->gd[0]->fops = &axi4sdcardblkdevops;
	//sdcard->gd[0]->events = DISK_EVENT_MEDIA_CHANGE; // TODO: To uncomment once partition reload has been implemented ...
	sdcard->gd[0]->private_data = sdcard;
	strcpy(sdcard->gd[0]->disk_name, axi4sdcardblkdevname);
	sdcard->gd[0]->queue = sdcard->blkqueue;
	// set_capacity() called twice
	// before and after add_disk()
	// to work around a Linux bug.
	set_capacity(sdcard->gd[0], 0); // Setting the capacity of the device in its gendisk structure.
	add_disk(sdcard->gd[0]); // Adding the disk to the system.
	set_capacity(sdcard->gd[0], sdcard->blkcnt[0]); // Setting the capacity of the device in its gendisk structure.
	
	// Additional block device files
	// are created for as many
	// partitions that exist.
	
	if (debug == 1 || debug == -1) {
		printk(KERN_INFO "axi4sdcard: %s created\n", sdcard->gd[0]->disk_name);
	}
	
	uint i = 1; do {
		// Skip if partition not used.
		if (!sdcard->blkcnt[i]) {
			sdcard->gd[i] = (struct gendisk*)0;
			continue;
		}
		
		if (!(sdcard->gd[i] = alloc_disk(1))) goto cleanup2;
		
		sdcard->gd[i]->major = sdcard->majornum;
		sdcard->gd[i]->first_minor = i;
		sdcard->gd[i]->fops = &axi4sdcardblkdevops;
		//sdcard->gd[i]->events = DISK_EVENT_MEDIA_CHANGE; // TODO: To uncomment once partition reload has been implemented ...
		sdcard->gd[i]->private_data = sdcard;
		snprintf(sdcard->gd[i]->disk_name, sizeof(sdcard->gd[i]->disk_name), "%s%u", axi4sdcardblkdevname, i);
		sdcard->gd[i]->queue = sdcard->blkqueue;
		// set_capacity() called twice
		// before and after add_disk()
		// to work around a Linux bug.
		set_capacity(sdcard->gd[i], 0); // Setting the capacity of the device in its gendisk structure.
		add_disk(sdcard->gd[i]); // Adding the disk to the system.
		set_capacity(sdcard->gd[i], sdcard->blkcnt[i]); // Setting the capacity of the device in its gendisk structure.
		
		if (debug == 1 || debug == -1) {
			printk(KERN_INFO "axi4sdcard: %s created\n", sdcard->gd[i]->disk_name);
		}
		
	} while (++i < MAXNBROFBLKDEVFILES);
	
	if (debug == 1 || debug == -1) {
		printk(KERN_INFO "axi4sdcard: %s() exit\n", __FUNCTION__);
	}
	
	++probecnt;
	
	return 0;
	
	cleanup2:
	
	if (debug == 1 || debug == -1) {
		printk(KERN_INFO "axi4sdcard: cleanup2\n");
	}
	
	i = 0; do {
		// Skip if gendisk was not allocated.
		if (!sdcard->gd[i]) continue;
		
		del_gendisk(sdcard->gd[i]);
		put_disk(sdcard->gd[i]);
		
	} while (++i < MAXNBROFBLKDEVFILES);
	
	unregister_blkdev(sdcard->majornum, "axi4sdcard");
	
	cleanup1:
	
	if (debug == 1 || debug == -1) {
		printk(KERN_INFO "axi4sdcard: cleanup1\n");
	}
	
	blk_cleanup_queue(sdcard->blkqueue);
	
	cleanup0:
	
	if (debug == 1 || debug == -1) {
		printk(KERN_INFO "axi4sdcard: cleanup0\n");
	}
	
	if (sdcard->cntrlr.irq) free_irq(sdcard->cntrlr.irq, sdcard);
	
	if (sdcard->workqueue) {
		flush_workqueue(sdcard->workqueue);
		destroy_workqueue(sdcard->workqueue);
	}
	
	iounmap(sdcard->cntrlr.addr);
	
	kfree(sdcard->drvname);
	kfree(sdcard);
	
	if (debug == 1 || debug == -1) {
		printk(KERN_INFO "axi4sdcard: %s() exit\n", __FUNCTION__);
	}
	
	return -ENOMEM;
}

static int axi4sdcard_drv_remove (struct platform_device* pdev) {
	
	if (debug == 1 || debug == -1) {
		printk(KERN_INFO "axi4sdcard: %s() entry\n", __FUNCTION__);
	}
	
	struct axi4sdcard* sdcard = platform_get_drvdata(pdev);
	
	if (sdcard->cntrlr.irq) free_irq(sdcard->cntrlr.irq, sdcard);
	
	uint i = 0; do {
		// Skip if gendisk was not allocated.
		if (!sdcard->gd[i]) continue;
		
		del_gendisk(sdcard->gd[i]);
		put_disk(sdcard->gd[i]);
		
	} while (++i < MAXNBROFBLKDEVFILES);
	
	unregister_blkdev(sdcard->majornum, axi4sdcardblkdevname);
	
	blk_cleanup_queue(sdcard->blkqueue);
	
	if (sdcard->workqueue) {
		flush_workqueue(sdcard->workqueue);
		destroy_workqueue(sdcard->workqueue);
	}
	
	iounmap(sdcard->cntrlr.addr);
	
	kfree(sdcard->drvname);
	kfree(sdcard);
	
	if (debug == 1 || debug == -1) {
		printk(KERN_INFO "axi4sdcard: %s() exit\n", __FUNCTION__);
	}
	
	return 0;
}

static struct platform_driver axi4sdcard_platform_driver = {
	.probe = axi4sdcard_drv_probe,
	.remove = axi4sdcard_drv_remove,
	.driver = {
		.name = "axi4sdcard",
		.owner = THIS_MODULE,
		.of_match_table = axi4sdcard_of_match,
	},
};

int __init axi4sdcard_init (void) {
	
	if (debug == 1 || debug == -1) {
		printk(KERN_INFO "axi4sdcard: %s() entry\n", __FUNCTION__);
	}
	
	// As soon as this function is called,
	// axi4sdcard_drv_probe() get called.
	int rc = platform_driver_register(&axi4sdcard_platform_driver);
	
	if (debug == 1 || debug == -1) {
		printk(KERN_INFO "axi4sdcard: %s() exit\n", __FUNCTION__);
	}
	
	return rc;
}

void __exit axi4sdcard_exit (void) {
	
	if (debug == 1 || debug == -1) {
		printk(KERN_INFO "axi4sdcard: %s() entry\n", __FUNCTION__);
	}
	
	platform_driver_unregister(&axi4sdcard_platform_driver);
	
	if (debug == 1 || debug == -1) {
		printk(KERN_INFO "axi4sdcard: %s() exit\n", __FUNCTION__);
	}
}

MODULE_LICENSE("GPL v2");
MODULE_AUTHOR("Christian Tambe");
MODULE_AUTHOR("William Fonkou Tambe");
MODULE_DESCRIPTION("AXI4 SDCard Block Device Driver");

module_init(axi4sdcard_init);
module_exit(axi4sdcard_exit);
