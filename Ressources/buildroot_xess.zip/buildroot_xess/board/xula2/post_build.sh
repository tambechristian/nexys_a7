#!/bin/sh

touch ${TARGET_DIR}/etc/modules

#fgrep axi4sdcard ${TARGET_DIR}/etc/modules || echo axi4sdcard >> ${TARGET_DIR}/etc/modules
