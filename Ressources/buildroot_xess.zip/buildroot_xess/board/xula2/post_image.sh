#!/bin/sh

# Convert the generated elf-image to a raw executable.
${HOST_DIR}/usr/bin/microblazeel-linux-objcopy \
	-O binary \
	${BINARIES_DIR}/simpleImage.xilinx \
	${BINARIES_DIR}/simpleImage.bin

chmod a-x ${BINARIES_DIR}/simpleImage.bin
